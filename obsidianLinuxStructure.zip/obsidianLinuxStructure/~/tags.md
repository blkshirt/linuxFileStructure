
#readmetxt #file #root #bin #boot #dev #etc #opt #home #lib #mnt #sbin #tmp #usr #include #local #share #man #var #cache #lock #log #run #spool #yp #/