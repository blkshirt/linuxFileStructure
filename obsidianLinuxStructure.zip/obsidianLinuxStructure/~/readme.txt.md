linux file structure organization
exactly what it sounds like
each directory will have a readme

#readmetxt 