"## headings ##"
H1, H2, etc

bold = ** **
italic = * *
strikethrough = ~~ ~~
highlight = == ==
bold and nested italic = ** ** and _ _
bold and italic = *** *** and ___ ___

internal links!!

inline link using brackets and url using parenthesis
escape the url by placing angled brackets

quotes!!
quote text by adding a > before the text

task lists!!
create it by placing a hyphen space brackets
-  [x] 

nesting lists!!
use tab to indent or shift tab to indent one or more items
like this
- 1 
	- 2


CODE!!

inline code
format code within a sentence using backticks
text inside `backticks`

code blkocks
```
cd ~/
```
you can even add syntax
```js
function fancyAlert(arg) {
if(arg)
	$.facebox({div:'#foo'})
}
```

footnotes!!
to add footnotes use the following syntax:
this is a simple footnote[^1]. [^1]: This is the referenced text. [^2]: Add 2 spaces at the start of each new line. This lets you write footnotes that span multiple lines. [^note]: Named footnotes still appear as numbers, but can make it easier to identify and link references.
you can also use them inline like ^[this is a footnote]

comments!!
%% inline comment %%
%%
block comment
%%

