static files of boot loader

kernel
system map
vmlinuz
intrd
grub
moduleinfo
boot

#readmetxt #boot #root 