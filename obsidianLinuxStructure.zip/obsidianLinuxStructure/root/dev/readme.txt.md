location of special or device files [contains makedev] 

#readmetxt #dev  #root 