library and kernel modules

#readmetxt #lib #root 