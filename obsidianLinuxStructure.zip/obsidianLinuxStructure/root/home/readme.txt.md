
user home directories

#readmetxt #home #root 