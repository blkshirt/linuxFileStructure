shareable and read only data

#readmetxt #usr