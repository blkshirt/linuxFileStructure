
obj, bin, lib files for prog and packages

#readmetxt #lib #usr