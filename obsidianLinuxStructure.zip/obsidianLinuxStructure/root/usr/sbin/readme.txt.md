non essential binaries are here

#readmetxt #sbin #usr