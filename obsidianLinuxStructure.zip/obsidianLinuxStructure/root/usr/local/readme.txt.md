local software here

#readmetxt #local #usr