manual and guide pages stored here

#readmetxt #man #usr #share