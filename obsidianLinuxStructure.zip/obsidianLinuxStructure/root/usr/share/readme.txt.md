static data shareable among all architectures

#readmetxt #usr #share