
mount files for temporary file systems

#readmetxt #mnt #root 