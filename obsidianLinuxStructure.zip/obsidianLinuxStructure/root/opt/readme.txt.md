add on application software

#readmetxt #opt #root 