variable state information remains here after reboot

#readmetxt #var #lib 