variable data of packaged installed

#readmetxt #var #opt 