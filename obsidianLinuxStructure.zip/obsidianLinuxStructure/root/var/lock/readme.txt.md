lock files for share resources

#readmetxt #var #lock 