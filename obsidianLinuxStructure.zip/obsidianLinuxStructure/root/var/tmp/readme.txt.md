available for prog

#readmetxt #var #tmp 