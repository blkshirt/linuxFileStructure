variable data files stored here

#readmetxt #var