log files

#readmetxt #var #log 