application cache data

#readmetxt #var #cache 