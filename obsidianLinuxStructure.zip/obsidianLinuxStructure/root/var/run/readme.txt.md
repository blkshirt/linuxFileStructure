info of system since it was booted

#readmetxt #var #run 