data for NIS services

#readmetxt #var #yp 