data awaiting processing

#readmetxt #var #spool 