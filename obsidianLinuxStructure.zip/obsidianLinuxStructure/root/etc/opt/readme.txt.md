
config file for addon application software

#readmetxt #opt #etc 