
host specific system config
```
csh.login
exports
fs tab
ftpusers
gateways
gettydefs
group
host.conf
hosts
hosts.allow
hosts.deny
hosts.equiv
hosts.lpd
inetd.conf
initab
issue
ls.so.conf
motd
mtab
mtools
networks
passwd
printcap
profile
protocols
resolv.conf
rpc
securetty
services
shells
syslog.conf
```

#readmetxt #etc #root 