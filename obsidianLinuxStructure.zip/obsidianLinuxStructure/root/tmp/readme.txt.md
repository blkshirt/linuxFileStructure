temporary files deleted on bootup

#readmetxt #tmp #root 