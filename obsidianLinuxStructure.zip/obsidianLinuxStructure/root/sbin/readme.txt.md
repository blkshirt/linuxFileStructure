system binaries

```

fastboot
fasthalt
fdisk
fs ck
getty
halt
ifconfig
init
mkfs
mkswap
reboot
route
swapon
swapoff
update

```


#readmetxt #sbin #root 